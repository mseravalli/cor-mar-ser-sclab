#!/bin/bash

rm *.txt nohup*

<<<<<<< HEAD
#/mount/applic/packages/matlab-7.13/bin/matlab -nodesktop -nosplash < testTime.m 
octave < testTime.m 
=======
/mount/applic/packages/matlab-7.13/bin/matlab -nodesktop -nosplash < testTime.m 
>>>>>>> 383760dac0c337577d1cf66ffccdc88859abc2c2


